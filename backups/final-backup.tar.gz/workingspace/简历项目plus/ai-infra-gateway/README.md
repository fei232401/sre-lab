# AI Infra Gateway

<div align="center">

[![Python](https://img.shields.io/badge/Python-3.11%2B-3776AB?logo=python)](https://python.org)
[![FastAPI](https://img.shields.io/badge/FastAPI-0.100%2B-009688?logo=fastapi)](https://fastapi.tiangolo.com)
[![Ollama](https://img.shields.io/badge/Ollama-0.30%2B-white?logo=ollama)](https://ollama.com)
[![License](https://img.shields.io/badge/license-MIT-green)](./LICENSE)
[![Status](https://img.shields.io/badge/status-production%20ready-brightgreen)]()
[![Platform](https://img.shields.io/badge/platform-Windows%2011-0078D6?logo=windows)]()

**Enterprise LLM Inference Gateway on Windows Bare Metal — No Docker, No K8s, Just GPU**

[Quick Start](#-quick-start) · [Architecture](#-architecture) · [Benchmark](#-benchmark-results) · [Troubleshooting](docs/troubleshooting.md) · [Changelog](CHANGELOG.md) · [Full Story](docs/PROJECT_NARRATIVE.md)

</div>

---

## Table of Contents

1. [Overview](#-overview)
2. [Architecture](#-architecture)
3. [Quick Start](#-quick-start)
4. [Benchmark Results](#-benchmark-results)
5. [Troubleshooting Highlights](#-troubleshooting-highlights)
6. [Tech Stack](#-tech-stack)
7. [Roadmap](#-roadmap)
8. [Document Index](#-document-index)

---

## 🎯 Overview

A production-grade LLM inference API gateway built entirely on **Windows 11 bare metal** with a single **NVIDIA RTX 4060 Laptop GPU (8GB)** — no Docker, no Kubernetes, no WSL2.

| Key Capability | Implementation |
|---------------|----------------|
| Authentication | JWT (HS256) + API Key fallback |
| Rate Limiting | Token Bucket (5 QPS, burst=10) |
| Resilience | Circuit Breaker (3-failure → OPEN) + Retry (2x, 1s backoff) |
| Streaming | SSE proxy — per-token forwarding to client |
| Monitoring | Real-time GPU dashboard (pynvml + matplotlib, 4 panels, 3s refresh) |
| Benchmarking | Dual-model C1-C8 concurrency gradient with TTFT/TPOT/Throughput/P99 |

**Core Achievement**: Complete AI Infra inference service chain on a constrained Windows environment — engineering over infrastructure.

> For the full environment baseline, project backstory, and deep-dive into every design decision, see **[PROJECT_NARRATIVE.md](docs/PROJECT_NARRATIVE.md)**.

---

## 🏗️ Architecture

```
                   ┌─────────────────┐
                   │   Dashboard v2  │  :9090  GPU real-time monitor
                   │  (FastAPI+matp) │
                   └────────┬────────┘
                            │ pynvml (NVIDIA driver-level sampling)
┌──────────┐    ┌───────────▼──────────────┐    ┌──────────┐
│  Client  │───▶│   Inference Gateway :8000 │───▶│  Ollama  │
│  (HTTP)  │    │  Auth + RateLimit + SSE   │    │  :11434  │
└──────────┘    └──────────────────────────┘    └──────────┘
     │                │              │                │
     ▼                ▼              ▼                ▼
 Bearer Token     Token Bucket    SSE Stream      RTX 4060
 JWT / API Key    (5 QPS, b=10)   per-token       8GB VRAM
```

### Layers

| Layer | Technology | Role |
|-------|-----------|------|
| Inference Engine | Ollama + qwen2.5:1.5b/0.5b | GPU-accelerated LLM inference |
| API Gateway | FastAPI + aiohttp | Async high-concurrency proxy |
| Auth | Bearer Token middleware (JWT HS256) | API Key / Token verification |
| Rate Limiting | Token Bucket algorithm | Backend protection, burst-tolerant |
| Streaming | SSE (Server-Sent Events) | Per-token push over HTTP |
| Monitoring | pynvml + matplotlib | GPU real-time dashboard |
| Benchmarking | asyncio + aiohttp | Concurrency gradient testing |

---

## 🚀 Quick Start

```powershell
# 1. Start Ollama inference engine
C:\Users\admin\AppData\Local\Programs\Ollama\ollama.exe serve

# 2. Start API Gateway
cd 01-gateway-server
python start_gateway.py                    # → http://localhost:8000

# 3. Start GPU dashboard
cd 02-dashboard
python dashboard_v2.py                     # → http://localhost:9090

# 4. Run full benchmark
cd 03-benchmark
python benchmark_final.py

# 5. API docs (Swagger)
# Open → http://localhost:8000/docs
```

---

## 📊 Benchmark Results

### Dual-Model Comparison: qwen2.5:0.5b vs qwen2.5:1.5b @ RTX 4060 Laptop 8GB

#### Ollama Local Baseline (RTX 4060 Laptop 8GB)

| Metric | qwen2.5:0.5b (397 MB) | qwen2.5:1.5b (986 MB) |
|--------|----------------------|----------------------|
| C1 Throughput | **198 t/s** | **132 t/s** |
| C1 TTFT | 3,383ms | 6,412ms |
| TPOT (avg) | 8ms | 14–15ms |
| TTFT degradation C1→C8 | +18% | +3% |
| Throughput inflection point | C2 | C8 |
| Success rate | 100% (32/32) | 100% (32/32) |

#### vLLM Cloud GPU (RTX 4090 24GB) — Measured + Extrapolated

| Metric | qwen2.5:0.5b (measured) | qwen2.5:1.5b (extrapolated*) |
|--------|------------------------|----------------------------|
| C1 Throughput | **5,132 t/s** | **1,711 t/s** |
| C4 Throughput | **17,778 t/s** | **5,926 t/s** |
| C8 Throughput | **14,603 t/s** | **4,868 t/s** |
| C16 Throughput | **15,350 t/s** | **5,117 t/s** |
| C1 TTFT | 32ms | 68ms |
| C16 TTFT | 50ms | 105ms |
| TPOT (avg) | 2ms | 6–7ms |
| Throughput inflection | C2 | C16 |
| Success rate | 100% (32/32) | 100%* |
| GPU | RTX 4090 24GB | RTX 4090 24GB |
| Engine | vLLM 0.23.0 | vLLM 0.23.0 |

> \*1.5B vLLM data extrapolated from 0.5B measurements using parameter-scaling model (3x parameter ratio). Cross-validated against Ollama local baseline. Full details in `05-autodl-benchmark/data/bench_qwen2.5-1.5b.json`.

### Key Takeaways

- 1.5B throughput is ~67% of 0.5B — scales linearly with parameter count
- Most tokens (P50–P90) return within 16ms — streaming pipeline is efficient
- 1.5B has better concurrency scalability (inflection at C8 vs C2)
- TTFT is dominated by cold-start model loading (2–5s); drops to 200–500ms after warm-up
- 64 total requests, zero failures — gateway robustness verified

> Full per-concurrency breakdown, token latency distributions, and analysis in **[PROJECT_NARRATIVE.md §8](docs/PROJECT_NARRATIVE.md#八双模型对比压测数据)**.

---

## 🔥 Troubleshooting Highlights

Five production-grade debugging records — each a self-contained case study.

| ID | Priority | Issue | Status |
|----|----------|-------|--------|
| T-001 | P0 | Ollama Registry blocked by GFW → GGUF local import bypass | ✅ Resolved |
| T-002 | P0 | Gateway 8000 port not listening after startup | ✅ Resolved |
| T-003 | P1 | PowerShell terminal stdout swallowed by IDE | 🟡 Workaround |
| T-004 | P2 | requirements.txt GBK encoding error on Windows pip | ✅ Resolved |
| T-005 | P1 | WSL2 / Hyper-V unavailable — OEM BIOS VT-x flag bug | 🔴 Hardware limit |

> Full root-cause analysis, diagnostic commands, and remediation steps: **[docs/troubleshooting.md](docs/troubleshooting.md)**

---

## 🛠️ Tech Stack

| Concern | Choice | Rationale |
|---------|--------|-----------|
| Inference | Ollama 0.30.9 | Native Windows support, no Docker/WSL2 required |
| API Server | FastAPI 0.100+ | Async-native, auto Swagger docs, SSE support |
| HTTP Client | aiohttp | Non-blocking connection pooling for proxy layer |
| Auth | PyJWT + Bearer Token middleware | Lightweight, no OAuth infrastructure needed |
| Rate Limiting | Token Bucket (in-memory) | Allows burst traffic, fits LLM inference patterns |
| Streaming | SSE (Server-Sent Events) | HTTP-native one-way push; simpler than WebSocket |
| GPU Monitoring | pynvml 11.0+ | Driver-level register sampling, zero external deps |
| Visualization | matplotlib (Agg backend) | Headless rendering to base64 PNG |
| Configuration | YAML | Human-readable, K8s ConfigMap-compatible format |

---

## 🗺️ Roadmap

| Priority | Feature | Status |
|----------|---------|--------|
| ✅ | JWT Auth (HS256, 60min expiry) | Done (v2.0) |
| ✅ | Circuit Breaker (3-failure → OPEN → 30s → HALF_OPEN) | Done (v2.0) |
| ✅ | Dual-Model Benchmark (0.5B vs 1.5B, C1–C8) | Done (v2.0) |
| ✅ | Prometheus Alerting Rules (GPU temp, memory, circuit breaker) | Done (v2.0) |
| ✅ | vLLM GPU Scheduling Benchmark (AutoDL RTX 4090) | Done ([data/](05-autodl-benchmark/data/)) |
| 🔄 | Token Latency Heatmap Dashboard | Planned |
| 🔄 | 3B / 7B IQ2 Quantized Model Testing | Blocked (GFW) |
| 🔄 | Redis-backed Distributed Rate Limiter | Planned |
| 🔄 | sglang Prefix Cache Comparison | Needs WSL2 |

### vLLM Benchmark (AutoDL Cloud GPU)

Scripts and templates ready in `05-autodl-benchmark/` — deploy vLLM on AutoDL RTX 4090, run C1-C8 gradient benchmark, and compare against local Ollama baseline:

> **Rental config**: RTX 4090 24GB, 32GB RAM, CUDA >= 12.1. SSH into instance → `bash vllm_deploy.sh` → `python vllm_benchmark.py` → `python vllm_report.py`.

### sglang Benchmark (Future)

Once WSL2 becomes available or sglang ships Windows support:

> Compare Ollama vs sglang on TTFT / TPOT / Memory Utilization under identical model and concurrency conditions, leveraging sglang's RadixAttention + Prefix Cache capabilities.

---

## 📑 Document Index

| Document | Purpose |
|----------|---------|
| **README.md** (this file) | Project entry point — architecture, quick start, key numbers |
| [PROJECT_NARRATIVE.md](docs/PROJECT_NARRATIVE.md) | Complete 11-chapter story: design decisions, interview prep, deep analysis |
| [FINAL_REPORT.md](docs/FINAL_REPORT.md) | Deliverable checklist + verification results |
| [troubleshooting.md](docs/troubleshooting.md) | T-001 ~ T-005 authoritative debug records |
| [ARCHITECT_AUDIT.md](docs/ARCHITECT_AUDIT.md) | Documentation quality audit & remediation tracker |
| [CHANGELOG.md](CHANGELOG.md) | v1.0 → v2.0 version history |
| [01-gateway-server/README.md](01-gateway-server/README.md) | Gateway module: design decisions, API reference |
| [02-dashboard/README.md](02-dashboard/README.md) | Dashboard module: architecture, monitoring metrics |
| [03-benchmark/README.md](03-benchmark/README.md) | Benchmark module: test matrix, output format (Ollama local) |
| [04-infrastructure/README.md](04-infrastructure/README.md) | Infrastructure tools: diagnostics, deployment scripts |
| [05-autodl-benchmark/README.md](05-autodl-benchmark/README.md) | Cloud GPU benchmark: vLLM deploy + SRE-LAB aligned step-pressure + comparison |
| [SRE_LAB_ARCHITECT_COMPARISON.md](docs/SRE_LAB_ARCHITECT_COMPARISON.md) | Cross-project architecture audit: bare metal vs K3S vs vLLM |
| **[AI Model Scheduler](../aimodel-scheduler/)** | 🆕 第三项目：统一异构调度层，连接 Gateway + SRE-LAB |

---

## 📄 License

MIT — see [LICENSE](./LICENSE) for details.

---

*Built with FastAPI + Ollama + pynvml on Windows 11 · RTX 4060 Laptop GPU · v2.0.0*